#!/system/bin/sh
if ! applypatch -c EMMC:/dev/block/platform/msm_sdcc.1/by-name/recovery:7542784:54163838693de3f59139a74a63e0927bc5a95a0b; then
  log -t recovery "Installing new recovery image"
  applypatch -b /system/etc/recovery-resource.dat EMMC:/dev/block/platform/msm_sdcc.1/by-name/boot:8988672:82b57ed1bedc590513a9eb736b7ae7418e8a7f3d EMMC:/dev/block/platform/msm_sdcc.1/by-name/recovery 54163838693de3f59139a74a63e0927bc5a95a0b 7542784 82b57ed1bedc590513a9eb736b7ae7418e8a7f3d:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
